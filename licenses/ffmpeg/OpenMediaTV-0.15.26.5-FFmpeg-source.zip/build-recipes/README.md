# Own FFmpeg audio build (LGPL configuration)

This module uses upstream Media3 1.11.0 audio decoder Java/JNI code and FFmpeg
6.1.6. It does not use Jellyfin's GPL-labelled prebuilt AAR.

Pinned source revisions:

- Media3: `2bc207851df311340767e913931ca7b28cab1794`
- FFmpeg: `f1e3a2bf7a2f2cde936d1ed97f09a26853d20125`
- NDK: `28.2.13676358`; Android native minimum API: 24.

The configure recipe explicitly disables GPL, nonfree, version3, external
auto-detection, encoders, network protocols, demuxers and video decoders.
It enables AAC, AC3, EAC3, DTS (`dca`), TrueHD, MLP, MP3, FLAC, ALAC, Vorbis,
Opus, AMR-NB/WB and A-law/µ-law audio decoders. Ordinary linear PCM stays on
Media3's existing raw audio path. The experimental FFmpeg video renderer is
excluded. Video codecs, Dolby Vision and HDR remain dependent on Android's
decoder, video profile, display and output chain; this is not a promise of
universal playback or preservation of Atmos/DTS:X object metadata when decoded
to PCM.

FFmpeg is linked as separate shared libraries, not statically into the app.
The build checks licensing flags and enabled decoders before packaging. These
checks are not a legal opinion or an actual-media playback test.

## Linux / CI

Install Java 17, Android SDK/platform 36, NDK above, Git, make, CMake, Ninja and
Python 3. Set `ANDROID_HOME`, then run `bash tools/build-ffmpeg.sh` from the
project root. The result is `app/libs/openmedia-ffmpeg.aar` and a corresponding
source archive in `dist/`. The normal APK workflow invokes this before Gradle.
The Linux recipe has not yet been executed in GitHub Actions.

## Local Windows preparation

The portable MSYS2 tools are outside the project, in the workspace's
`work/audio-native-tools/msys64`. No WSL installation or reboot is required.
The experimental `tools/build-ffmpeg-windows.sh` accepts the checked-out FFmpeg
source, NDK directory, output directory and ABI, expressed as MSYS paths.
Run it once per `armeabi-v7a`, `arm64-v8a`, `x86_64`, then run
`tools/package-ffmpeg-local.ps1 -PythonPath <python.exe>` in PowerShell.
That packaging step checks the configuration, compiles the JNI bridge, and
builds the AAR. It does not generate a signed application APK.

## Distribution requirements

Distribute the corresponding FFmpeg source, exact build recipes, notices and
LGPL text alongside any APK containing these libraries. Include the upstream
Media3 Apache-2.0 notices as well. Keep the libraries replaceable/relinkable;
do not impose terms prohibiting reverse engineering for debugging modifications
to these LGPL components. Additional patent/distribution obligations can depend
on use and jurisdiction. Review the upstream guidance before public release:
https://ffmpeg.org/legal.html

Do not describe the decoder list as device-verified until the built AAR has
passed on-device loading and representative media playback tests.
