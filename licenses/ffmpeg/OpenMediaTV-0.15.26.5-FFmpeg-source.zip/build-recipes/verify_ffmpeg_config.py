"""Fail closed if FFmpeg enables GPL/nonfree or omits an intended audio decoder."""
import re
import sys
from pathlib import Path

DECODERS = 'aac ac3 eac3 dca truehd mlp mp3 flac alac vorbis opus amrnb amrwb pcm_mulaw pcm_alaw'.split()


def verify(text):
    values = dict(re.findall(r'^#define\s+(\w+)\s+([01])\s*$', text, re.MULTILINE))
    for flag in ('CONFIG_GPL', 'CONFIG_GPLV3', 'CONFIG_NONFREE', 'CONFIG_VERSION3'):
        if values.get(flag) != '0':
            raise ValueError('Disallowed or unverified licensing flag: ' + flag)
    for decoder in DECODERS:
        flag = 'CONFIG_' + decoder.upper() + '_DECODER'
        if values.get(flag) != '1':
            raise ValueError('Missing decoder: ' + decoder)


if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('Usage: verify_ffmpeg_config.py config.h config_components.h')
    verify('\n'.join(Path(p).read_text(encoding='utf-8') for p in sys.argv[1:]))
    print('Licensing flags and requested audio decoders verified.')
