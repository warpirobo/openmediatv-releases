"""Check packaged audio libraries: ELF architecture, 16 KiB LOAD alignment and Java bridge."""
import io
import struct
import sys
import zipfile

ARCHES = {'armeabi-v7a': (1, 40), 'arm64-v8a': (2, 183), 'x86_64': (2, 62)}
LIBRARIES = ('libffmpegJNI.so', 'libavcodec.so', 'libavutil.so', 'libswresample.so')


def verify_elf(data, abi):
    bits, machine = ARCHES[abi]
    assert data[:4] == b'\x7fELF' and data[4] == bits and data[5] == 1, abi
    assert struct.unpack_from('<H', data, 18)[0] == machine, abi
    offset = struct.unpack_from('<Q' if bits == 2 else '<I', data, 32 if bits == 2 else 28)[0]
    size, count = struct.unpack_from('<HH', data, 54 if bits == 2 else 42)
    loads = 0
    for index in range(count):
        header = offset + index * size
        if struct.unpack_from('<I', data, header)[0] == 1:
            loads += 1
            alignment = struct.unpack_from('<Q' if bits == 2 else '<I', data, header + (48 if bits == 2 else 28))[0]
            assert alignment >= 16384, (abi, alignment)
    assert loads > 0


def verify(path):
    with zipfile.ZipFile(path) as archive:
        prefix = 'jni' if path.endswith('.aar') else 'lib'
        for abi in ARCHES:
            # Split APKs only contain one architecture; AAR must contain all three.
            if prefix == 'lib' and not any(name.startswith('lib/' + abi + '/') for name in archive.namelist()):
                continue
            for name in LIBRARIES:
                verify_elf(archive.read(prefix + '/' + abi + '/' + name), abi)
        for name in ('FFmpeg-LGPL-2.1.txt', 'Media3-Apache-2.0.txt'):
            assert len(archive.read('assets/licenses/' + name)) > 1000
        if prefix == 'jni':
            with zipfile.ZipFile(io.BytesIO(archive.read('classes.jar'))) as classes:
                assert 'androidx/media3/decoder/ffmpeg/FfmpegAudioRenderer.class' in classes.namelist()
                assert not any('ExperimentalFfmpegVideoRenderer' in name for name in classes.namelist())
    print('Native audio architecture, alignment, bridge and notices verified:', path)


if __name__ == '__main__':
    for path in sys.argv[1:]:
        verify(path)
