#!/usr/bin/env bash
# Linux build only. Sources and native outputs stay under the module build directory.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
[[ "$(uname -s)" == Linux ]] || { echo 'FFmpeg build requires Linux (or WSL).'; exit 1; }
for tool in git make cmake ninja python3; do command -v "$tool" >/dev/null; done
: "${ANDROID_HOME:?Set ANDROID_HOME to an Android SDK}"
ndk="$ANDROID_HOME/ndk/28.2.13676358"
toolchain="$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin"
test -x "$toolchain/clang"
work="$root/native/ffmpeg/build"
mkdir -p "$work" "$root/dist" "$root/app/libs"
work="$(mktemp -d "$work/recipe-XXXXXXXX")"
media_commit=2bc207851df311340767e913931ca7b28cab1794
ffmpeg_commit=f1e3a2bf7a2f2cde936d1ed97f09a26853d20125
fetch_source() {
    git init -q "$3"
    git -C "$3" fetch --depth=1 "$1" "$2"
    git -C "$3" checkout -q --detach FETCH_HEAD
    test "$(git -C "$3" rev-parse HEAD)" = "$2"
}
fetch_source https://github.com/androidx/media.git "$media_commit" "$work/media"
fetch_source https://github.com/FFmpeg/FFmpeg.git "$ffmpeg_commit" "$work/ffmpeg"
decoders=(aac ac3 eac3 dca truehd mlp mp3 flac alac vorbis opus amrnb amrwb pcm_mulaw pcm_alaw)
decoder_flags=()
for decoder in "${decoders[@]}"; do decoder_flags+=("--enable-decoder=$decoder"); done
generated="$root/native/ffmpeg/build/generated"
mkdir -p "$generated/java" "$generated/assets/licenses" "$generated/jniLibs"
java_package=androidx/media3/decoder/ffmpeg
mkdir -p "$generated/java/$java_package"
for source in FfmpegAudioDecoder FfmpegAudioRenderer FfmpegDecoderException FfmpegLibrary package-info; do
    cp "$work/media/libraries/decoder_ffmpeg/src/main/java/$java_package/$source.java" "$generated/java/$java_package/"
done
cp "$work/ffmpeg/COPYING.LGPLv2.1" "$generated/assets/licenses/FFmpeg-LGPL-2.1.txt"
cp "$work/media/LICENSE" "$generated/assets/licenses/Media3-Apache-2.0.txt"
for abi in armeabi-v7a arm64-v8a x86_64; do
    case "$abi" in
        armeabi-v7a) arch=arm; triple=armv7a-linux-androideabi; extra=(--cpu=armv7-a) ;;
        arm64-v8a) arch=aarch64; triple=aarch64-linux-android; extra=(--cpu=armv8-a) ;;
        x86_64) arch=x86_64; triple=x86_64-linux-android; extra=(--disable-x86asm) ;;
    esac
    prefix="$work/install-$abi"
    mkdir -p "$work/compile-$abi" "$generated/jniLibs/$abi"
    (
        cd "$work/compile-$abi"
        "$work/ffmpeg/configure" --prefix="$prefix" --target-os=android --arch="$arch" \
            --enable-cross-compile --cc="$toolchain/${triple}24-clang" \
            --cxx="$toolchain/${triple}24-clang++" --ar="$toolchain/llvm-ar" \
            --nm="$toolchain/llvm-nm" --ranlib="$toolchain/llvm-ranlib" --strip="$toolchain/llvm-strip" \
            --disable-gpl --disable-nonfree --disable-version3 --disable-autodetect \
            --enable-shared --disable-static --enable-pic --disable-doc --disable-programs \
            --disable-everything --disable-network --disable-avdevice --disable-avformat \
            --disable-swscale --disable-postproc --disable-avfilter --enable-swresample \
            --disable-debug --disable-symver --extra-ldflags=-Wl,-z,max-page-size=16384 \
            "${extra[@]}" "${decoder_flags[@]}"
        python3 "$root/tools/verify_ffmpeg_config.py" config.h config_components.h
        make -j"${OPENMEDIA_NATIVE_JOBS:-2}"
        make install
    )
    cmake -S "$root/native/ffmpeg" -B "$work/bridge-$abi" -G Ninja \
        -DCMAKE_TOOLCHAIN_FILE="$ndk/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-24 -DANDROID_STL=c++_static \
        -DCMAKE_BUILD_TYPE=Release -DFFMPEG_PREFIX="$prefix" -DMEDIA_SOURCE="$work/media"
    cmake --build "$work/bridge-$abi" --parallel "${OPENMEDIA_NATIVE_JOBS:-2}"
    for component in avcodec swresample avutil; do
        cp -L "$prefix/lib/lib${component}.so" "$generated/jniLibs/$abi/"
    done
    cp "$work/bridge-$abi/libffmpegJNI.so" "$generated/jniLibs/$abi/"
done
bash gradlew --no-daemon --max-workers=2 -PbuildFfmpeg=true :ffmpeg:assembleRelease
cp native/ffmpeg/build/outputs/aar/ffmpeg-release.aar app/libs/openmedia-ffmpeg.aar
python3 tools/verify_native_audio.py app/libs/openmedia-ffmpeg.aar
# Preserve corresponding upstream source and the exact local recipe with every binary release.
git -C "$work/ffmpeg" archive --format=tar --prefix=FFmpeg/ HEAD | gzip -n > "$work/FFmpeg-source.tar.gz"
git -C "$work/media" archive --format=tar --prefix=Media3/ HEAD libraries/decoder_ffmpeg LICENSE | gzip -n > "$work/Media3-source.tar.gz"
cp tools/build-ffmpeg.sh tools/verify_ffmpeg_config.py "$work/"
cp native/ffmpeg/CMakeLists.txt native/ffmpeg/build.gradle.kts "$work/"
tar -czf dist/openmedia-ffmpeg-corresponding-source.tar.gz -C "$work" \
    FFmpeg-source.tar.gz Media3-source.tar.gz build-ffmpeg.sh verify_ffmpeg_config.py CMakeLists.txt build.gradle.kts \
    compile-armeabi-v7a/config.h compile-armeabi-v7a/config_components.h \
    compile-arm64-v8a/config.h compile-arm64-v8a/config_components.h \
    compile-x86_64/config.h compile-x86_64/config_components.h
sha256sum app/libs/openmedia-ffmpeg.aar dist/openmedia-ffmpeg-corresponding-source.tar.gz
