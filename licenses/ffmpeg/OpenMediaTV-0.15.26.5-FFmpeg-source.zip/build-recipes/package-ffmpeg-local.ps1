param([Parameter(Mandatory=$true)][string]$PythonPath)
$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$workspace = Split-Path -Parent (Split-Path -Parent $project)
$audioRoot = Join-Path $workspace 'work\audio-native-tools'
$ndkRoot = Join-Path $workspace 'work\android-build\sdk\ndk\28.2.13676358'
$clang = Join-Path $ndkRoot 'toolchains\llvm\prebuilt\windows-x86_64\bin\clang++.exe'
$generated = Join-Path $project 'native\ffmpeg\build\generated'
$mediaCommit = '2bc207851df311340767e913931ca7b28cab1794'
$jniSource = Join-Path $audioRoot 'ffmpeg_jni.cc'
# Download the bridge from the exact same revision as its Java classes.
Invoke-WebRequest "https://raw.githubusercontent.com/androidx/media/$mediaCommit/libraries/decoder_ffmpeg/src/main/jni/ffmpeg_jni.cc" -OutFile $jniSource
$package = 'androidx/media3/decoder/ffmpeg'
$javaDir = Join-Path $generated "java/$package"
New-Item -ItemType Directory -Path $javaDir -Force | Out-Null
foreach ($name in @('FfmpegAudioDecoder', 'FfmpegAudioRenderer', 'FfmpegDecoderException', 'FfmpegLibrary', 'package-info')) {
    Invoke-WebRequest "https://raw.githubusercontent.com/androidx/media/$mediaCommit/libraries/decoder_ffmpeg/src/main/java/$package/$name.java" -OutFile (Join-Path $javaDir "$name.java")
}
foreach ($abi in @('armeabi-v7a','arm64-v8a','x86_64')) {
    $compile = Join-Path $audioRoot "native-output/$abi"
    & $PythonPath (Join-Path $PSScriptRoot 'verify_ffmpeg_config.py') (Join-Path $compile 'config.h') (Join-Path $compile 'config_components.h')
    if ($LASTEXITCODE) { throw "FFmpeg licensing/decoder audit failed: $abi" }
    $prefix = Join-Path $audioRoot "native-output/install-$abi"
    $destination = Join-Path $generated "jniLibs/$abi"
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    $target = switch ($abi) { 'armeabi-v7a' { 'armv7a-linux-androideabi24' }; 'arm64-v8a' { 'aarch64-linux-android24' }; 'x86_64' { 'x86_64-linux-android24' } }
    foreach ($library in @('avcodec','avutil','swresample')) {
        $binary = Join-Path $prefix "lib/lib$library.so"
        if (-not (Test-Path -LiteralPath $binary)) { throw "Missing native library: $abi / $library" }
        Copy-Item -LiteralPath $binary -Destination $destination
    }
    & $clang "--target=$target" '-std=c++17' '-shared' '-fPIC' '-O2' '-static-libstdc++' '-Wl,-z,max-page-size=16384' '-Wl,-soname,libffmpegJNI.so' "-I$(Join-Path $prefix 'include')" $jniSource "-L$(Join-Path $prefix 'lib')" '-lavcodec' '-lswresample' '-lavutil' '-landroid' '-llog' '-o' (Join-Path $destination 'libffmpegJNI.so')
    if ($LASTEXITCODE) { throw "JNI bridge compilation failed: $abi" }
}
$licenses = Join-Path $generated 'assets/licenses'
New-Item -ItemType Directory -Path $licenses -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $audioRoot 'ffmpeg-6.1.6/COPYING.LGPLv2.1') -Destination (Join-Path $licenses 'FFmpeg-LGPL-2.1.txt')
Invoke-WebRequest "https://raw.githubusercontent.com/androidx/media/$mediaCommit/LICENSE" -OutFile (Join-Path $licenses 'Media3-Apache-2.0.txt')
& (Join-Path $PSScriptRoot 'compile-local.ps1') -Tasks @('-PbuildFfmpeg=true', ':ffmpeg:assembleRelease')
Copy-Item -LiteralPath (Join-Path $project 'native/ffmpeg/build/outputs/aar/ffmpeg-release.aar') -Destination (Join-Path $project 'app/libs/openmedia-ffmpeg.aar')
& $PythonPath (Join-Path $PSScriptRoot 'verify_native_audio.py') (Join-Path $project 'app/libs/openmedia-ffmpeg.aar')
if ($LASTEXITCODE) { throw 'Native audio package validation failed' }
Get-FileHash -LiteralPath (Join-Path $project 'app/libs/openmedia-ffmpeg.aar') -Algorithm SHA256
