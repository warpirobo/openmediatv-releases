plugins { id("com.android.library") }

android {
    namespace = "androidx.media3.decoder.ffmpeg"
    compileSdk = 36
    defaultConfig { minSdk = 24 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
androidComponents.onVariants { variant ->
    variant.sources.java?.addStaticSourceDirectory("build/generated/java")
    variant.sources.jniLibs?.addStaticSourceDirectory("build/generated/jniLibs")
    variant.sources.assets?.addStaticSourceDirectory("build/generated/assets")
}
tasks.withType<JavaCompile>().configureEach {
    exclude("**/ExperimentalFfmpegVideoRenderer.java")
}
dependencies {
    implementation("androidx.annotation:annotation:1.9.1")
    api("androidx.media3:media3-decoder:1.11.0")
    implementation("androidx.media3:media3-exoplayer:1.11.0")
    compileOnly("org.checkerframework:checker-qual:3.49.0")
}
