#!/usr/bin/env bash
# Experimental native Windows/MSYS2 path; the Linux recipe remains the CI reference.
set -euo pipefail
source_dir="$1"
ndk_dir="$2"
output_dir="$3"
abi="${4:-arm64-v8a}"
toolchain="$ndk_dir/toolchains/llvm/prebuilt/windows-x86_64/bin"
case "$abi" in
    arm64-v8a) arch=aarch64; target=aarch64-linux-android24; extra=(--cpu=armv8-a) ;;
    armeabi-v7a) arch=arm; target=armv7a-linux-androideabi24; extra=(--cpu=armv7-a) ;;
    x86_64) arch=x86_64; target=x86_64-linux-android24; extra=(--disable-x86asm) ;;
    *) exit 2 ;;
esac
mkdir -p "$output_dir/$abi"
cd "$output_dir/$abi"
"$source_dir/configure" --prefix="$output_dir/install-$abi" --target-os=android --arch="$arch" \
    --enable-cross-compile --cc="$toolchain/clang.exe --target=$target" \
    --cxx="$toolchain/clang++.exe --target=$target" --ar="$toolchain/llvm-ar.exe" \
    --nm="$toolchain/llvm-nm.exe" --ranlib="$toolchain/llvm-ranlib.exe" --strip="$toolchain/llvm-strip.exe" \
    --disable-gpl --disable-nonfree --disable-version3 --disable-autodetect \
    --enable-shared --disable-static --enable-pic --disable-doc --disable-programs \
    --disable-everything --disable-network --disable-avdevice --disable-avformat \
    --disable-swscale --disable-postproc --disable-avfilter --enable-swresample \
    --disable-debug --disable-symver --extra-ldflags=-Wl,-z,max-page-size=16384 \
    --enable-decoder=aac,ac3,eac3,dca,truehd,mlp,mp3,flac,alac,vorbis,opus,amrnb,amrwb,pcm_mulaw,pcm_alaw \
    "${extra[@]}"
# Verify these files using verify_ffmpeg_config.py before packaging the output.
make -j2
make install
